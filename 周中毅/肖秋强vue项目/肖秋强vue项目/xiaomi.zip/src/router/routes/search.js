export default {
    path:'/search',
    name:"搜索",
    component:()=>import("../../views/search.vue")
}