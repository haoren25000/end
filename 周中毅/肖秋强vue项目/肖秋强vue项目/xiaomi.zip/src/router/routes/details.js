export default {
    path:'/details',
    name:"详情",
    component:()=>import("../../views/details.vue")
}