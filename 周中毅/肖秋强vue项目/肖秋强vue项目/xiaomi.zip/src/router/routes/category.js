// 分类
export default {
    path:'/category',
    name:"分类",
    component:()=>import("../../views/category.vue")
}