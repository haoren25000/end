<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
    data() {
      return {
      }
    },
}
</script>

<style lang="scss">
#app{
  padding-bottom: 50px;
}
</style>
